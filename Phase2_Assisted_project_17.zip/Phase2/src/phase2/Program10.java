package phase2;
package com.example.web;

import com.example.model.Product;
import com.example.util.HibernateUtil;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.hibernate.Session;
import org.hibernate.Transaction;

@WebServlet("/addProduct")
public class Program10 extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) {
     String productName = request.getParameter("productName");
     double price = Double.parseDouble(request.getParameter("price"));
     int quantity = Integer.parseInt(request.getParameter("quantity"));

     // Create a new product
     Product product = new Product();
     product.setProductName(productName);
     product.setPrice(price);
     product.setQuantity(quantity);

     // Save the product to the database
     try (Session session = HibernateUtil.getSessionFactory().openSession()) {
         Transaction transaction = session.beginTransaction();
         session.save(product);
         transaction.commit();
     } catch (Exception e) {
         e.printStackTrace();
        
     }

     // Redirect to a success page or display a message
     // (You might want to handle this according to your application's needs)
     response.sendRedirect("success.jsp");
 }
}

public class  {

}

package phase2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class program3 {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/exampledb";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                System.out.println("Connected to the database!");

                // Create a statement
                try (Statement statement = connection.createStatement()) {

                    // Create a table (if not exists)
                    createTable(statement);

                    // Insert data
                    insertData(statement, 1, "John Doe", 30);
                    insertData(statement, 2, "Jane Smith", 25);

                    // Query data
                    queryData(statement);

                } // Auto-closes the Statement

            } // Auto-closes the Connection

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTable(Statement statement) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS employees (id INT PRIMARY KEY, name VARCHAR(255), age INT)";
        statement.executeUpdate(createTableSQL);
        System.out.println("Table 'employees' created or already exists.");
    }

    private static void insertData(Statement statement, int id, String name, int age) throws SQLException {
        String insertSQL = "INSERT INTO employees (id, name, age) VALUES (" + id + ", '" + name + "', " + age + ")";
        statement.executeUpdate(insertSQL);
        System.out.println("Data inserted into the 'employees' table.");
    }

    private static void queryData(Statement statement) throws SQLException {
        String querySQL = "SELECT * FROM employees";
        try (ResultSet resultSet = statement.executeQuery(querySQL)) {

            System.out.println("Querying data from the 'employees' table:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
            }
        }
    }
}


package thread;
class one extends Thread {
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("HI");
		   try { Thread.sleep(1000);}catch(Exception e){}
		   //without create any thread 
		   //we can use thread function because by default 
		   // main is a thread
		}}}
class two extends Thread{
	public void run() { // when we make classes to thread we change the function name to "run"
		for(int i=1;i<=5;i++) {
			System.out.println("HELLO");
		 try { Thread.sleep(1000);}catch(Exception e){}
		}}}
public class Thread_1 {
	public static void main(String[] args) {
		one obj1=new one();
		two obj2=new two();
		obj1.start(); // if we run two methods simultaneously then output looks like hi hi hello hello hello hello hi hi
		 try { Thread.sleep(10);}catch(Exception e) {}
		obj2.start();
}}

package assisted_project;

public class Constructor {
	private int x;
	
	void show_data() {
		System.out.println("The value of x"+x);}
	void value(int i) {
		System.out.println("Print the value"+i);
		
	}

	public static void main(String[] args) {
		Constructor n=new Constructor();
		Constructor n1=new Constructor();
		n.show_data();//Default Constructor
        n1.value(10);//Parameterized Constructor
        
	}

}

package phase2;
//Usage example to demonstrate component mapping
public class Program14 {

 public static void main(String[] args) {
     SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
     try (Session session = sessionFactory.openSession()) {
         Transaction transaction = session.beginTransaction();

         // Create a Person with an embedded Address
         Person person = new Person();
         person.setName("John Doe");

         Address address = new Address();
         address.setStreet("123 Main St");
         address.setCity("Anytown");
         address.setZipCode("12345");

         person.setAddress(address);

         // Save the Person entity to the database
         session.save(person);

         transaction.commit();
     }
 }
}



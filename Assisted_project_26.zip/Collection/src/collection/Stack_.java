package collection;
import java.util.Stack;
public class Stack_ {

	public static void main(String[] args) {
	    Stack<String> animal=new Stack<>();
	    animal.push("lion");
	    animal.push("cat");
	    animal.push("dog");
	    System.out.println(animal);
	    System.out.println(animal.peek());//top element will show
	    animal.pop();//top element will delete
	    System.out.println(animal);
	}

}

package assisted_project;
import java.util.*;
public class Type_casting {

	public static void main(String[] args) {
					Scanner sc=new Scanner(System.in);
					System.out.println("Enter a number:");
					int num= sc.nextInt();
					System.out.println("Before conversion :"+ num);
					double num1=num;
					System.out.println("Implicit conversion integer to double:"+num1);
					System.out.println("Enter a number:");
					double num2= sc.nextDouble();
					System.out.println("Before conversion :"+ num2);
					int num3=(int)num2;
					String num4=String.valueOf( num2);
					System.out.println("Explicit conversion double to integer :"+num3);
					System.out.println("Explicit conversion double to String :"+num4);
			        sc.close();

	}

}

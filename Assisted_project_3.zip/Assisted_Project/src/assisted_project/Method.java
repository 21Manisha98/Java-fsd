package assisted_project;

public class Method {
	static void my() {//Implementation of a method
		System.out.println("Hello World!");
	}

	public static void main(String[] args) {
		my();//calling a method

	}

}

package assisted_project;
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}
public class Finally_ {

	
	    public static void main(String[] args) {
	        try {
	            // Code that may throw an exception
	            performOperation(5, 0);
	        } catch (CustomException ce) {
	            System.out.println("Caught CustomException: " + ce.getMessage());
	        } catch (ArithmeticException ae) {
	            System.out.println("Caught ArithmeticException: " + ae.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }

	    // Method that declares to throw an exception
	    private static void performOperation(int num1, int num2) throws CustomException {
	        if (num2 == 0) {
	            // Throwing a custom exception
	            throw new CustomException("Division by zero is not allowed.");
	        }

	        int result = num1 / num2;
	        System.out.println("Result of the division: " + result);
	    }
	}

 

package assisted_project;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;
public class CURD {
	public static void main(String[] args) {
        String fileName = "example.txt";
        // Create a file
        createFile(fileName);
        // Write content to the file
        writeToFile(fileName, "Hello, World!");
        // Read content from the file
        readFromFile(fileName);
        // Update content in the file
        updateFile(fileName, "Updated content.");
        // Read updated content from the file
        readFromFile(fileName);
        // Delete the file
        deleteFile(fileName);
    }
  // Create a file
    private static void createFile(String fileName) {
        Path path = Paths.get(fileName);
        try {
            Files.createFile(path);
            System.out.println("File created: " + fileName);
        } catch (IOException e) {
            System.err.println("Error creating file: " + e.getMessage());
        }
    }

    // Write content to the file
    private static void writeToFile(String fileName, String content) {
        Path path = Paths.get(fileName);

        try {
            Files.write(path, content.getBytes(), StandardOpenOption.WRITE);
            System.out.println("Content written to the file.");
        } catch (IOException e) {
            System.err.println("Error writing to the file: " + e.getMessage());
        }
    }

    // Read content from the file
    private static void readFromFile(String fileName) {
        Path path = Paths.get(fileName);

        try {
            List<String> lines = Files.readAllLines(path);
            System.out.println("Content read from the file:");
            for (String line : lines) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading from the file: " + e.getMessage());
        }
    }

    // Update content in the file
    private static void updateFile(String fileName, String updatedContent) {
        Path path = Paths.get(fileName);

        try {
            Files.write(path, updatedContent.getBytes(), StandardOpenOption.WRITE);
            System.out.println("Content updated in the file.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }

    // Delete the file
    private static void deleteFile(String fileName) {
        Path path = Paths.get(fileName);

        try {
            Files.deleteIfExists(path);
            System.out.println("File deleted: " + fileName);
        } catch (IOException e) {
            System.err.println("Error deleting the file: " + e.getMessage());
        }
    }
}

package project;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.*;
class UserInfo {
    private String username;
    private String password;
    private double walletAmt;
    // Constructors
    public UserInfo() {
    }

    public UserInfo(String username, String password, double walletAmt) {
        this.username = username;
        this.password = password;
        this.walletAmt = walletAmt;
    }
 // Getters and Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public double getWalletAmt() {
        return walletAmt;
    }

    public void setWalletAmt(double walletAmt) {
        this.walletAmt = walletAmt;
    }
    public void addAmtToWallet1() {
        System.out.println("Current Wallet Balance: $" + walletAmt);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter amount to add to wallet: $");
        double amount = scanner.nextDouble();
        walletAmt += amount;
        System.out.println("Wallet amount added successfully. New balance: $" + walletAmt);
    }
}

class Camera {
    private int camid;
    private String brand;
    private String model;
    private float rentPerDay;
    private String status;

    // Constructors, getters, and setters
    public Camera() {
        this.camid = camid;
        this.brand = brand;
        this.model = model;
        this.rentPerDay = rentPerDay;
        this.status = status;
    }
 // Getters and Setters
    public int getCamid() {
        return camid;
    }

    public void setCamid(int camid) {
        this.camid = camid;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }  public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public float getRentPerDay() {
        return rentPerDay;
    }

    public void setRentPerDay(float rentPerDay) {
        this.rentPerDay = rentPerDay;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

class CameraOperations {
    private List<Camera> rentACamera = new ArrayList<>();

    public String addCamera(Camera cm) {
        cm.setStatus("Available");
        rentACamera.add(cm);
        return "Camera added successfully.";
    }

    public List<Camera> showAllCameras() {
        Collections.sort(rentACamera, Comparator.comparingInt(Camera::getCamid));
        return rentACamera;
    }

    public String deleteCamera(int camid) {
        Camera camera = findCamera(camid);
        if (camera != null) {
            if ("Rented".equals(camera.getStatus())) {
                return "Cannot delete a rented camera.";
            } else {
                rentACamera.remove(camera);
                return "Camera deleted successfully.";
            }
        }
        return "Camera not found.";
    }

    public void rentACamera(int camid, double walletAmt) {
        Camera camera = findCamera(camid);
        if (camera != null) {
            if ("Available".equals(camera.getStatus())) {
                System.out.println("Rent Per Day: $" + camera.getRentPerDay());
                System.out.println("Wallet Balance: $" + walletAmt);

                if (walletAmt >= camera.getRentPerDay()) {
                    camera.setStatus("Rented");
                    System.out.println("Camera rented successfully!");
                } else {
                    System.out.println("Insufficient wallet balance. Cannot rent the camera.");
                }
            } else {
                System.out.println("Camera is already rented.");
            }
        } else {
            System.out.println("Camera not found.");
        }
    }

    private Camera findCamera(int camid) {
        for (Camera camera : rentACamera) {
            if (camera.getCamid() == camid) {
                return camera;
            }
        }
        return null;
    }
}

public class CAMERA1{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserInfo user = new UserInfo();
        user.setUsername("admin");
        user.setPassword("admin@123");
        user.setWalletAmt(10000.00);

        System.out.print("Enter username: ");
        String inputUsername = scanner.nextLine();
        System.out.print("Enter password: ");
        String inputPassword = scanner.nextLine();

        if (inputUsername.equals(user.getUsername()) && inputPassword.equals(user.getPassword())) {
            CameraOperations cameraOperations = new CameraOperations();
            double walletAmt = user.getWalletAmt();

            while (true) {
                System.out.println("\n===== Main Menu =====");
                System.out.println("1. My Camera");
                System.out.println("2. Rent A Camera");
                System.out.println("3. View All Cameras");
                System.out.println("4. My Wallet");
                System.out.println("5. Exit");

                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        myCameraSubMenu(scanner, cameraOperations);
                        break;
                    case 2:
                        System.out.println("\n===== Rent a Camera =====");
                        System.out.println("Available Cameras:");
                        List<Camera> availableCameras = cameraOperations.showAllCameras();
                        for (Camera camera : availableCameras) {
                            if ("Available".equals(camera.getStatus())) {
                                System.out.println("ID: " + camera.getCamid() +
                                        ", Brand: " + camera.getBrand() +
                                        ", Model: " + camera.getModel() +
                                        ", Rent Per Day: $" + camera.getRentPerDay());
                            }
                        }
                        System.out.print("Enter the camera ID to rent: ");
                        int camToRent = scanner.nextInt();
                        cameraOperations.rentACamera(camToRent, walletAmt);
                        break;
                    case 3:
                        System.out.println("\n===== View All Cameras =====");
                        List<Camera> allCameras = cameraOperations.showAllCameras();
                        for (Camera camera : allCameras) {
                            System.out.println("ID: " + camera.getCamid() +
                                    ", Brand: " + camera.getBrand() +
                                    ", Model: " + camera.getModel() +
                                    ", Rent Per Day: $" + camera.getRentPerDay() +
                                    ", Status: " + camera.getStatus());
                        }
                        break;
                    case 4:
                        System.out.println("\n===== My Wallet =====");
                        System.out.println("Wallet Balance: $" + walletAmt);
                        break;
                    case 5:
                        System.out.println("Exiting the application. Thank you!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } else {
            System.out.println("Incorrect username/password.");
        }
    }

    private static void myCameraSubMenu(Scanner scanner, CameraOperations cameraOperations) {
        while (true) {
            System.out.println("\n===== My Camera =====");
            System.out.println("1. Add Camera");
            System.out.println("2. Remove Camera");
            System.out.println("3. View Cameras");
            System.out.println("4. Back to Main Menu");

            System.out.print("Enter your choice: ");
            int subChoice = scanner.nextInt();

            switch (subChoice) {
                case 1:
                    addCameraSubMenu(scanner, cameraOperations);
                    break;
                case 2:
                    removeCameraSubMenu(scanner, cameraOperations);
                    break;
                case 3:
                    System.out.println("\n===== My Cameras =====");
                    List<Camera> myCameras = cameraOperations.showAllCameras();
                    for (Camera camera : myCameras) {
                        System.out.println("ID: " + camera.getCamid() +
                                ", Brand: " + camera.getBrand() +
                                ", Model: " + camera.getModel() +
                                ", Rent Per Day: $" + camera.getRentPerDay() +
                                ", Status: " + camera.getStatus());
                    }
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCameraSubMenu(Scanner scanner, CameraOperations cameraOperations) {
        System.out.println("\n===== Add Camera =====");
        System.out.print("Enter brand: ");
        String brand = scanner.next();
        System.out.print("Enter model: ");
        String model = scanner.next();
        System.out.print("Enter rent per day: $");
        float rentPerDay = scanner.nextFloat();

        Camera newCamera = new Camera();
        newCamera.setBrand(brand);
        newCamera.setModel(model);
        newCamera.setRentPerDay(rentPerDay);

        String result = cameraOperations.addCamera(newCamera);
        System.out.println(result);
        }
    private static void removeCameraSubMenu(Scanner scanner, CameraOperations cameraOperations) {
        System.out.println("\n===== Remove Camera =====");
        System.out.print("Enter camera ID to remove: ");
        int camidToRemove = scanner.nextInt();

        String result = cameraOperations.deleteCamera(camidToRemove);
        System.out.println(result);
    }
}
       




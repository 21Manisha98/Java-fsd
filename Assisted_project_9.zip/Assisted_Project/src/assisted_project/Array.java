package assisted_project;
import java.util.*;
public class Array {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in); 
		System.out.println("Enter the size of an array");
		int m=sc.nextInt();
		int a[]=new int[m];
		for(int i=0;i<m;i++) {
			a[i]=sc.nextInt();
		}
		for(int i=0;i<m;i++) {
			System.out.println(a[i]);
		}
		sc.close();
	}

}

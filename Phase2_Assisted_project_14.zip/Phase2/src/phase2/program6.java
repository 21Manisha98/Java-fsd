package phase2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class program6 {

    // JDBC URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    // Database name
    private static final String DATABASE_NAME = "example_database";

    public static void main(String[] args) {
        // Create a new database
        createDatabase();

        // Select the newly created database
        selectDatabase();

        // Drop (delete) the database
        dropDatabase();
    }

    private static void createDatabase() {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection without specifying a database (connecting to the MySQL server)
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                // Create a Statement object
                try (Statement statement = connection.createStatement()) {
                    // SQL statement to create a new database
                    String createDatabaseSQL = "CREATE DATABASE " + DATABASE_NAME;

                    // Execute the SQL statement
                    statement.executeUpdate(createDatabaseSQL);

                    System.out.println("Database created successfully.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void selectDatabase() {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection to the specific database
            try (Connection connection = DriverManager.getConnection(JDBC_URL + DATABASE_NAME, USERNAME, PASSWORD)) {
                System.out.println("Connected to the database: " + DATABASE_NAME);
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void dropDatabase() {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection without specifying a database (connecting to the MySQL server)
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                // Create a Statement object
                try (Statement statement = connection.createStatement()) {
                    // SQL statement to drop (delete) the database
                    String dropDatabaseSQL = "DROP DATABASE " + DATABASE_NAME;

                    // Execute the SQL statement
                    statement.executeUpdate(dropDatabaseSQL);

                    System.out.println("Database dropped successfully.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}



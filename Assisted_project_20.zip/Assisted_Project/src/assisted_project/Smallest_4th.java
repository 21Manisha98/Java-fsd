package assisted_project;
import java.util.*;
public class Smallest_4th {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		int m=sc.nextInt();
		System.out.println("Enter the position");
		int K
		=sc.nextInt();
		int []arr=new int[m];
		for (int i=0;i<m;i++) {
			System.out.println("Enter the value");
			arr[i]=sc.nextInt();
		}
		System.out.println("Array:");
		for (int i=0;i<m;i++) {
			System.out.print(arr[i]+" ");}
		 // Function call
        System.out.print("K'th smallest element is "
                         + kthSmallest(arr, K));
			sc.close();
	}
	public static int kthSmallest(int[] arr, int K)
    {
        // Sort the given array
        Arrays.sort(arr);
        // Return K'th element in
        // the sorted array
        return arr[K - 1];
    }

}

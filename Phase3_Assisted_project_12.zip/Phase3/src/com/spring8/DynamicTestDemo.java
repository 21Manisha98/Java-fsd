package com.spring8;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import java.util.Arrays;
import java.util.Collection;
import static org.junit.jupiter.api.Assertions.*;

public class DynamicTestDemo {

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                DynamicTest.dynamicTest("Test Addition", () -> {
                    int result = add(3, 4);
                    assertEquals(7, result);
                }),
                DynamicTest.dynamicTest("Test Subtraction", () -> {
                    int result = subtract(5, 2);
                    assertEquals(3, result);
                }),
                DynamicTest.dynamicTest("Test Multiplication", () -> {
                    int result = multiply(3, 6);
                    assertEquals(18, result);
                }),
                DynamicTest.dynamicTest("Test Division", () -> {
                    double result = divide(8, 2);
                    assertEquals(4.0, result, 0.001);
                })
        );
    }

    private int add(int a, int b) {
        return a + b;
    }

    private int subtract(int a, int b) {
        return a - b;
    }

    private int multiply(int a, int b) {
        return a * b;
    }

    private double divide(int a, int b) {
        if (b == 0) {
            throw new IllegalArgumentException("Cannot divide by zero");
        }
        return (double) a / b;
    }
}


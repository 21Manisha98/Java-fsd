package assisted_project;
import java.util.*;
public class Rotated_Array {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of an array:");
		int m=sc.nextInt();
		int []arr=new int[m];
		for (int i=0;i<m;i++) {
			System.out.println("Enter the value");
			arr[i]=sc.nextInt();
		}
		System.out.println("Array:");
		for (int i=0;i<m;i++) {
			System.out.print(arr[i]+" ");
			
		}
		for(int j=0;j<3;j++) {
			int i,last;
			last=arr[m-1];
         for(i=m-1;i>0;i--) {
        	 arr[i]=arr[i-1];
        	 
         }
         arr[0]=last;
         }
		System.out.print(" After Right Rotated Array:");
		for (int i=0;i<m;i++) {
			System.out.print(arr[i]+" ");
			
		}
     sc.close();
	}

}

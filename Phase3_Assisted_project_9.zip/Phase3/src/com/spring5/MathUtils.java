package com.spring5;
public class MathUtils {

    public static int factorial(int n) {
        assert n >= 0 : "Input should be a non-negative integer";
        
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }

    public static void main(String[] args) {
        // Test the factorial method with assertions
        testFactorial();
    }

    private static void testFactorial() {
        assert factorial(0) == 1 : "Factorial of 0 should be 1";
        assert factorial(1) == 1 : "Factorial of 1 should be 1";
        assert factorial(5) == 120 : "Factorial of 5 should be 120";
        assert factorial(10) == 3628800 : "Factorial of 10 should be 3628800";
        
        // Uncomment the line below to trigger an assertion failure
        // assert factorial(-1) == -1 : "Factorial of -1 should not be defined";
        
        System.out.println("All assertions passed!");
    }
}


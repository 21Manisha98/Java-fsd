package assisted_project;
//Class representing a basic shape
class Shape {
 // Fields
 private String color;
// Constructor
 public Shape(String color) {
     this.color = color;
 }
 // Getter method for color
 public String getColor() {
     return color;
 }
// Method to calculate area (to be overridden by subclasses)
 public double calculateArea() {
     return 0.0;
 }
// Method to display information about the shape
 public void displayInfo() {
     System.out.println("This is a " + color + " shape.");
 }
}
//Subclass representing a circle (inherits from Shape)
class Circle extends Shape {
 // Fields
 private double radius;
// Constructor
 public Circle(String color, double radius) {
     super(color);
     this.radius = radius;
 }
 // Overridden method to calculate area for a circle
 @Override
 public double calculateArea() {
     return Math.PI * radius * radius;
 }

 // Overridden method to display information about the circle
 @Override
 public void displayInfo() {
     System.out.println("This is a " + getColor() + " circle with radius " + radius + ".");
 }
}

//Subclass representing a rectangle (inherits from Shape)
class Rectangle extends Shape {
 // Fields
 private double length;
 private double width;

 // Constructor
 public Rectangle(String color, double length, double width) {
     super(color);
     this.length = length;
     this.width = width;
 }

 // Overridden method to calculate area for a rectangle
 @Override
 public double calculateArea() {
     return length * width;
 }
 // Overridden method to display information about the rectangle
 @Override
 public void displayInfo() {
     System.out.println("This is a " + getColor() + " rectangle with length " + length + " and width " + width + ".");
 }
}
public class Main {
 public static void main(String[] args) {
     // Creating objects of different shapes
     Circle myCircle = new Circle("Red", 5.0);
     Rectangle myRectangle = new Rectangle("Blue", 4.0, 6.0);
     // Demonstrating polymorphism and abstraction
     Shape shape1 = myCircle;
     Shape shape2 = myRectangle;
     // Displaying information and calculating area for each shape
     shape1.displayInfo();
     System.out.println("Area: " + shape1.calculateArea());
     shape2.displayInfo();
     System.out.println("Area: " + shape2.calculateArea());
 }
}


package collection;
import java.util.Comparator;
import java.util.PriorityQueue;
public class PriorityQueue_ {
     public static void main(String args[]) {
    	 PriorityQueue<Integer> pq= new PriorityQueue<>(Comparator.reverseOrder());
    	 //by default min heap kaj kore.max heap korte comparator use korte lage 
    	 pq.offer(45);
    	 pq.offer(56);
    	 pq.offer(85);
    	 System.out.println(pq);
    	 pq.poll();
    	 System.out.println(pq);
    	 System.out.println(pq.peek());
     }
}

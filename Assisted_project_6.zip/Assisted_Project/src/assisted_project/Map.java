package assisted_project;
import java.util.HashMap;

public class Map{
    public static void main(String[] args) {
        // HashMap demonstration
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);

        System.out.println("HashMap:");
        Map(hashMap);

        // Accessing values from HashMap
        System.out.println("Value corresponding to 'Two': " + hashMap.get("Two"));

        // Checking if a key exists
        String keyToCheck = "Four";
        System.out.println("Does key '" + keyToCheck + "' exist? " + hashMap.containsKey(keyToCheck));

        // Removing a key-value pair
        String keyToRemove = "Two";
        hashMap.remove(keyToRemove);
        System.out.println("After removing key '" + keyToRemove + "':");
        Map(hashMap);
    }

    // Utility method to print the contents of a map
    private static void Map(Map<String, Integer> map) {
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
        System.out.println();
    }
}

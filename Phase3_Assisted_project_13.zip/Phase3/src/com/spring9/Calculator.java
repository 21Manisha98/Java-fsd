package com.spring9;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
class Calculator {

    private final MathOperation mathOperation;

    @Autowired
    public Calculator(MathOperation mathOperation) {
        this.mathOperation = mathOperation;
    }

    public int performOperation(int a, int b) {
        return mathOperation.operate(a, b);
    }
}

interface MathOperation {
    int operate(int a, int b);
}

@Component
class AdditionOperation implements MathOperation {
    @Override
    public int operate(int a, int b) {
        return a + b;
    }
}

@Component
class SubtractionOperation implements MathOperation {
    @Override
    public int operate(int a, int b) {
        return a - b;
    }
}

public class DependencyInjectionExample {

    public static void main(String[] args) {
        // Initialize Spring ApplicationContext
        ApplicationContext context = new AnnotationConfigApplicationContext(DependencyInjectionExample.class);

        // Retrieve the Calculator bean from the ApplicationContext
        Calculator calculator = context.getBean(Calculator.class);

        // Use the Calculator with injected MathOperation
        int result = calculator.performOperation(5, 3);
        System.out.println("Result: " + result);
    }
}


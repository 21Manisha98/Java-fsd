package assisted_project;
import java.util.*;
public class Collection {

	public static void main(String[] args) {
		        // ArrayList demonstration
		        List<String> arrayList = new ArrayList<>();
		        arrayList.add("Java");
		        arrayList.add("Python");
		        arrayList.add("C++");
		        System.out.println("ArrayList: " + arrayList);

		        // LinkedList demonstration
		        List<String> linkedList = new LinkedList<>();
		        linkedList.add("Apple");
		        linkedList.add("Banana");
		        linkedList.add("Orange");
		        System.out.println("LinkedList: " + linkedList);

		        // HashSet demonstration
		        Set<String> hashSet = new HashSet<>();
		        hashSet.add("Red");
		        hashSet.add("Green");
		        hashSet.add("Blue");
		        System.out.println("HashSet: " + hashSet);

		        // HashMap demonstration
		        Map<Integer, String> hashMap = new HashMap<>();
		        hashMap.put(1, "One");
		        hashMap.put(2, "Two");
		        hashMap.put(3, "Three");
		        System.out.println("HashMap: " + hashMap);

		        // TreeMap demonstration
		        Map<Integer, String> treeMap = new TreeMap<>();
		        treeMap.put(3, "Three");
		        treeMap.put(1, "One");
		        treeMap.put(2, "Two");
		        System.out.println("TreeMap: " + treeMap);
		    }
		


	}



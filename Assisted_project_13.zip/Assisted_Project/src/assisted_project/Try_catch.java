package assisted_project;

public class Try_catch {

	public static void main(String[] args) {
		try {
			//Block of code to try
		      int[] myNumbers = {1, 2, 3};
		      System.out.println(myNumbers[10]);
		    } catch (Exception e) {
		    	//Block of code to handle errors
		      System.out.println("Something went wrong.");
		    }
		  }
	}



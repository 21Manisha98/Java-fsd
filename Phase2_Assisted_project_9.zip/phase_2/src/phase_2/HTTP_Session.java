package phase_2;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class HTTP_Session extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the existing session or create a new one if not exists
        HttpSession session = request.getSession(true);

        // Set some session attributes (you can store any data in the session)
        session.setAttribute("username", "john_doe");
        session.setAttribute("userRole", "admin");

        // Display the session information
        out.println("<html><body>");
        out.println("<h2>Session Information</h2>");
        out.println("<p>Session ID: " + session.getId() + "</p>");
        out.println("<p>Username: " + session.getAttribute("username") + "</p>");
        out.println("<p>User Role: " + session.getAttribute("userRole") + "</p>");
        out.println("<p><a href='/YourProjectName/SessionServlet'>Refresh</a></p>");
        out.println("</body></html>");
    }
}


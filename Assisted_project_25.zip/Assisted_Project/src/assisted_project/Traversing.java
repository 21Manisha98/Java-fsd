package assisted_project;
import java.util.*;
import java.lang.*;
class node{
    int key;
    node prev;
    node next;
    node(){
        prev = null;
        next = null;
    }}
public class Traversing {
	static node head = null;
    static node first = null;
    static node tail = null;
    static node temp = null;
    static int i = 0;
    static void addnode(int k)
    {
        node ptr = new node();
        ptr.key = k;
        ptr.next = null;
        ptr.prev = null;
        if (head == null) {
            head = ptr;
            first = head;
            tail = head;
        }
        else {
            temp = ptr;
            first.next = temp;
            temp.prev = first;
            first = temp;
            tail = temp;
        }
        i++;
    }
    static void traverse()
    {
        node ptr = head;
        while (ptr != null) {
            System.out.print( ptr.key+" ");
            ptr = ptr.next;
        }
        System.out.println();
    }
    static void insertatbegin(int k)
    {
        node ptr = new node();
        ptr.key = k;
        ptr.next = null;
        ptr.prev = null;
        if (head == null) {
            first = ptr;
            first = head;
            tail = head;
        }
        else {
            temp = ptr;
            temp.next = head;
            head.prev = temp;
            head = temp;
        }
        i++;
    }
    static void insertatend(int k)
    {
        node ptr= new node();
        ptr.key = k;
        ptr.next = null;
        ptr.prev = null;
        if (head == null) {
            first = ptr;
            first = head;
            tail = head;
        }
        else {
            temp = ptr;
            temp.prev = tail;
            tail.next = temp;
            tail = temp;
        }
        i++;
    }
    static void insertatpos(int k, int pos)
    {
        if (pos < 1 || pos > i + 1) {
            System.out.println("Please enter a valid position");
        }
        else if (pos == 1) {
            insertatbegin(k);
        }
        else if (pos == i + 1) {
            insertatend(k);
        }
        else {
            node src = head;
            while (pos--!=0) {
                src = src.next;
            }
            node da, ba;
            node ptr = new node();
            ptr.next = null;
            ptr.prev = null;
            ptr.key = k;
            ba = src;
            da = (src.prev);
            ptr.next = (ba);
            ptr.prev = (da);
            da.next = ptr;
            ba.prev = ptr;
            i++;
        }
    }
    static void delatbegin()
    {
        head = head.next;
        i--;
    }
    static void delatend()
    {
        tail = tail.prev;
        tail.next = null;
        i--;}
    static void delatpos(int pos)
    { if (pos < 1 || pos > i + 1) {
            System.out.println("Please enter a valid position");
        }
        else if (pos == 1) {
            delatbegin();
        }
        else if (pos == i) {
            delatend();
        }
        else {
            node src = head;
            pos--;
            while (pos--!=0) {
                src = src.next;
            }
            node pre, aft;
            pre = (src.prev);
            aft = (src.next);
            pre.next = (aft);
            aft.prev = (pre);
            i--;
        }
    }
	public static void main(String[] args) {
		 addnode(2);
	        addnode(4);
	        addnode(9);
	        addnode(1);
	        addnode(21);
	        addnode(22);
	        System.out.print("Linked List: ");
	        traverse();
	        System.out.println();
	        insertatbegin(1);
	        System.out.print("Linked List after inserting 1 at beginning: ");
	        traverse();
	        insertatend(0);
	        System.out.print("Linked List after inserting 0 at end: ");
	        traverse();
	        insertatpos(44, 3);
	        System.out.print("Linked List after inserting 44 after 3rd Node: ");
	        traverse();
	        System.out.println();
	        delatbegin();
	        System.out.print("Linked List after deleting node at beginning: ");
	        traverse();
	        delatend();
	        System.out.print("Linked List after deleting node at end: ");
	        traverse();
	        System.out.print("Linked List after deleting node at position 5: ");
	        delatpos(5);
	        traverse();
		

	}

}

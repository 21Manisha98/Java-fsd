package assisted_project;
class Access_modifiers {

	public int x1;		//public
	int x2;        		//Default
	protected int x3=55;//protected
	private int x4;		//private
	public  void ma() {
		x1=10;
	}
}
 class B {
	public void mB() {
		Access_modifiers a = new Access_modifiers();
		
		a.x1=55;
		a.x2=55;
		a.x3=55;
		//compiler error
		//Because private class can not be 
		//accessed in other class
		//a.x4=55;
		
		a.ma();
		
	}
}

package phase_2;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class Log_in extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the username and password from the request parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // In a real-world scenario, you would validate the username and password against a database
        // For simplicity, let's assume a valid login for any non-empty username and password

        if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
            // Create a new session or get the existing session
            HttpSession session = request.getSession(true);

            // Set the username in the session attribute
            session.setAttribute("username", username);

            // Display the welcome message
            out.println("<html><body>");
            out.println("<h2>Welcome, " + username + "!</h2>");
            out.println("<p><a href='/YourProjectName/LogoutServlet'>Logout</a></p>");
            out.println("</body></html>");
        } else {
            // Invalid login, display an error message
            out.println("<html><body>");
            out.println("<h2>Invalid login. Please try again.</h2>");
            out.println("<p><a href='/YourProjectName/login.html'>Login</a></p>");
            out.println("</body></html>");
        }
    }
}


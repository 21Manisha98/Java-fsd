package phase_2;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SessionServlet")
public class Hidden_file extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the existing session or create a new one if not exists
        HttpSession session = request.getSession(true);

        // Display the session information and include a form with a hidden field
        out.println("<html><body>");
        out.println("<h2>Session Information</h2>");
        out.println("<p>Session ID: " + session.getId() + "</p>");

        // Include a form with a hidden input field containing the session ID
        out.println("<form action='/YourProjectName/SessionServlet' method='post'>");
        out.println("<input type='hidden' name='sessionId' value='" + session.getId() + "'>");
        out.println("<input type='submit' value='Refresh'>");
        out.println("</form>");

        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // The doPost method can handle form submissions if needed
        doGet(request, response);
    }
}


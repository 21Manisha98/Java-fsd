package phase2;
package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class program1 {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        // Load the JDBC driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return;
        }

        // Establish a connection
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            System.out.println("Connected to the database!");

            // Create a table
            createTable(connection);

            // Insert data
            insertData(connection);

            // Query data
            queryData(connection);

            // Update data
            updateData(connection);

            // Query data after update
            queryData(connection);

            // Delete data
            deleteData(connection);

            // Query data after delete
            queryData(connection);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTable(Connection connection) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY, name VARCHAR(255))";
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(createTableSQL);
            System.out.println("Table 'users' created or already exists.");
        }
    }

    private static void insertData(Connection connection) throws SQLException {
        String insertSQL = "INSERT INTO users (id, name) VALUES (?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.setString(2, "John Doe");
            preparedStatement.executeUpdate();
            System.out.println("Data inserted into the 'users' table.");
        }
    }

    private static void queryData(Connection connection) throws SQLException {
        String querySQL = "SELECT * FROM users";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(querySQL)) {

            System.out.println("Querying data from the 'users' table:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                System.out.println("ID: " + id + ", Name: " + name);
            }
        }
    }

    private static void updateData(Connection connection) throws SQLException {
        String updateSQL = "UPDATE users SET name = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
            preparedStatement.setString(1, "Jane Doe");
            preparedStatement.setInt(2, 1);
            preparedStatement.executeUpdate();
            System.out.println("Data updated in the 'users' table.");
        }
    }

    private static void deleteData(Connection connection) throws SQLException {
        String deleteSQL = "DELETE FROM users WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            preparedStatement.setInt(1, 1);
            preparedStatement.executeUpdate();
            System.out.println("Data deleted from the 'users' table.");
        }
    }
}


package phase2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class program7 {

    // JDBC URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        // Insert a new record
        insertRecord("John Doe", 25);

        // Update an existing record
        updateRecord(1, "Updated Name", 30);

        // Delete a record
        deleteRecord(2);
    }

    private static void insertRecord(String name, int age) {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                // SQL statement for insertion
                String insertSQL = "INSERT INTO employee (name, age) VALUES (?, ?)";

                // Create a PreparedStatement
                try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
                    // Set parameters
                    preparedStatement.setString(1, name);
                    preparedStatement.setInt(2, age);

                    // Execute the query
                    int rowsAffected = preparedStatement.executeUpdate();

                    System.out.println(rowsAffected + " row(s) inserted successfully.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateRecord(int id, String newName, int newAge) {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                // SQL statement for updating
                String updateSQL = "UPDATE employee SET name=?, age=? WHERE id=?";

                // Create a PreparedStatement
                try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
                    // Set parameters
                    preparedStatement.setString(1, newName);
                    preparedStatement.setInt(2, newAge);
                    preparedStatement.setInt(3, id);

                    // Execute the query
                    int rowsAffected = preparedStatement.executeUpdate();

                    System.out.println(rowsAffected + " row(s) updated successfully.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteRecord(int id) {
        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                // SQL statement for deletion
                String deleteSQL = "DELETE FROM employee WHERE id=?";

                // Create a PreparedStatement
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
                    // Set parameter
                    preparedStatement.setInt(1, id);

                    // Execute the query
                    int rowsAffected = preparedStatement.executeUpdate();

                    System.out.println(rowsAffected + " row(s) deleted successfully.");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}


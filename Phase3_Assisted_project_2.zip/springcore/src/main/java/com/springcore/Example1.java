package com.springcore;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.EventListener;

// Custom event class
class CustomEvent extends java.util.EventObject {
    public CustomEvent(Object source) {
        super(source);
    }
}

// Custom listener interface
interface CustomListener extends EventListener {
    void customEventOccurred(CustomEvent event);
}

// Class that generates custom events
class EventGenerator {
    private CustomListener listener;

    public void setCustomListener(CustomListener listener) {
        this.listener = listener;
    }

    public void fireEvent() {
        if (listener != null) {
            listener.customEventOccurred(new CustomEvent(this));
        }
    }
}

// GUI frame with default and custom event handling
public class Example1 extends JFrame {
    private JButton defaultEventButton;
    private JButton customEventButton;
    private EventGenerator eventGenerator;

    public Example1() {
        setTitle("Event Handling Demo");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 200);

        // Initialize components
        defaultEventButton = new JButton("Default Event");
        customEventButton = new JButton("Custom Event");
        eventGenerator = new EventGenerator();

        // Default event handling
        defaultEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(Example1.this, "Default Event Occurred!");
            }
        });

        // Custom event handling
        eventGenerator.setCustomListener(new CustomListener() {
            @Override
            public void customEventOccurred(CustomEvent event) {
                JOptionPane.showMessageDialog(Example1.this, "Custom Event Occurred!");
            }
        });

        customEventButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Trigger custom event
                eventGenerator.fireEvent();
            }
        });

        // Set layout
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        // Add components to the frame
        add(defaultEventButton);
        add(customEventButton);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Example1 demo = new Example1();
                demo.setVisible(true);
            }
        });
    }
}


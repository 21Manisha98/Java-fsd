package phase_2;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpResponse;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Servelet_")
public class Servelet_ extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpResponse response)
            throws ServletException, IOException {
        processRequest(request, response, "GET");
    }

    protected void doPost(phase_2.HttpServlet request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response, "POST");
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response, String method)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        try {
            String name = request.getParameter("name");
            String namePost = request.getParameter("namePost");

            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet GET/POST Example</title>");
            out.println("</head>");
            out.println("<body>");

            out.println("<h2>Servlet GET/POST Example - Result</h2>");

            if ("GET".equals(method)) {
                out.println("<p>You submitted using GET method. Your name is: " + name + "</p>");
            } else if ("POST".equals(method)) {
                out.println("<p>You submitted using POST method. Your name is: " + namePost + "</p>");
            }

            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }
}




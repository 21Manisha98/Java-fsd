package com.spring7;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NestedRepeatedTest {

    @Nested
    @DisplayName("Addition Tests")
    class AdditionTests {

        @Test
        @DisplayName("Adding positive numbers")
        void testAddPositiveNumbers() {
            assertEquals(4, add(2, 2));
        }

        @Test
        @DisplayName("Adding negative numbers")
        void testAddNegativeNumbers() {
            assertEquals(-3, add(-1, -2));
        }
    }

    @Nested
    @DisplayName("Subtraction Tests")
    class SubtractionTests {

        @Test
        @DisplayName("Subtracting positive numbers")
        void testSubtractPositiveNumbers() {
            assertEquals(3, subtract(5, 2));
        }

        @Test
        @DisplayName("Subtracting negative numbers")
        void testSubtractNegativeNumbers() {
            assertEquals(-1, subtract(-3, -2));
        }
    }

    @RepeatedTest(3)
    @DisplayName("Multiplication Test")
    void testMultiply() {
        assertEquals(12, multiply(3, 4));
    }

    private int add(int a, int b) {
        return a + b;
    }

    private int subtract(int a, int b) {
        return a - b;
    }

    private int multiply(int a, int b) {
        return a * b;
    }
}


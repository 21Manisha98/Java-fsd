package assisted_project;

  class OuterClass {
    // Member variable in the outer class
    private int outerVariable = 10;

    // Constructor of the outer class
    public OuterClass() {
        System.out.println("OuterClass constructor");
    }

    // Method in the outer class
    public void outerMethod() {
        System.out.println("OuterClass method");
    }

    // Inner class
    public class InnerClass {
        // Member variable in the inner class
        private int innerVariable = 20;

        // Constructor of the inner class
        public InnerClass() {
            System.out.println("InnerClass constructor");
        }

        // Method in the inner class
        public void innerMethod() {
            System.out.println("InnerClass method");
        }

        // Accessing outer class members from inner class
        public void accessOuterMembers() {
            System.out.println("Accessing outerVariable from InnerClass: " + outerVariable);
            outerMethod();
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class
        OuterClass outerObj = new OuterClass();

        // Creating an instance of the inner class
        OuterClass.InnerClass innerObj = outerObj.new InnerClass();

        // Calling methods of the inner class
        innerObj.innerMethod();
        innerObj.accessOuterMembers();
    }
}

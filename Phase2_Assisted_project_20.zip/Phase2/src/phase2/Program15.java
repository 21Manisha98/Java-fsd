package phase2;
//src/main/java/com/example/controller/ProductController.java
package com.example.controller;

import com.example.model.Product;
import com.example.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class Program15  {

 private final ProductService productService;

 @Autowired
 public ProductController(ProductService productService) {
     this.productService = productService;
 }

 @GetMapping("/products")
 public String getAllProducts(Model model) {
     model.addAttribute("products", productService.getAllProducts());
     return "product-list";
 }

 @GetMapping("/add-product")
 public String showAddProductForm(Model model) {
     model.addAttribute("product", new Product());
     return "add-product";
 }

 @PostMapping("/add-product")
 public String addProduct(Product product) {
     productService.saveProduct(product);
     return "redirect:/products";
 }
}


package phase2;
//src/com/example/model/Student.java
package com.example.model;

import java.util.List;
import javax.persistence.*;

@Entity
@Table(name = "students")
public class Program13 {

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;

 private String name;

 @ManyToMany(fetch = FetchType.LAZY) // Set lazy loading for the courses collection
 @JoinTable(
     name = "student_course",
     joinColumns = @JoinColumn(name = "student_id"),
     inverseJoinColumns = @JoinColumn(name = "course_id")
 )
 private List<Course> courses;

 // Getter and Setter for id
 public Long getId() {
     return id;
 }

 public void setId(Long id) {
     this.id = id;
 }

 // Getter and Setter for name
 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 // Getter and Setter for courses
 public List<Course> getCourses() {
     return courses;
 }

 public void setCourses(List<Course> courses) {
     this.courses = courses;
 }
}



package phase2;
//Usage example to demonstrate lazy loading
public class Mainapp {

 public static void main(String[] args) {
     SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
     try (Session session = sessionFactory.openSession()) {
         Transaction transaction = session.beginTransaction();

         // Load a student entity (assuming there is a student with ID 1 in the database)
         Student student = session.get(Student.class, 1L);

         // At this point, the courses collection is not loaded from the database

         // Access the courses collection - Hibernate will trigger the lazy loading
         List<Course> courses = student.getCourses();

         // Now the courses collection is loaded from the database

         transaction.commit();
     }
 }
}


package phase2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class program2 {

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/exampledb";
    private static final String USERNAME = "your_username";
    private static final String PASSWORD = "your_password";

    public static void main(String[] args) {
        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection
            try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
                System.out.println("Connected to the database!");

                // Create a table (if not exists)
                createTable(connection);

                // Insert data
                insertData(connection, 1, "John Doe", 30);
                insertData(connection, 2, "Jane Smith", 25);

                // Query data
                queryData(connection);

                // Update data
                updateData(connection, 1, "John Doe Jr.");

                // Query data after update
                queryData(connection);

                // Delete data
                deleteData(connection, 2);

                // Query data after delete
                queryData(connection);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTable(Connection connection) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS employees (id INT PRIMARY KEY, name VARCHAR(255), age INT)";
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(createTableSQL);
            System.out.println("Table 'employees' created or already exists.");
        }
    }

    private static void insertData(Connection connection, int id, String name, int age) throws SQLException {
        String insertSQL = "INSERT INTO employees (id, name, age) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertSQL)) {
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setInt(3, age);
            preparedStatement.executeUpdate();
            System.out.println("Data inserted into the 'employees' table.");
        }
    }

    private static void queryData(Connection connection) throws SQLException {
        String querySQL = "SELECT * FROM employees";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(querySQL)) {

            System.out.println("Querying data from the 'employees' table:");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age);
            }
        }
    }

    private static void updateData(Connection connection, int id, String newName) throws SQLException {
        String updateSQL = "UPDATE employees SET name = ? WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(updateSQL)) {
            preparedStatement.setString(1, newName);
            preparedStatement.setInt(2, id);
            preparedStatement.executeUpdate();
            System.out.println("Data updated in the 'employees' table.");
        }
    }

    private static void deleteData(Connection connection, int id) throws SQLException {
        String deleteSQL = "DELETE FROM employees WHERE id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteSQL)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            System.out.println("Data deleted from the 'employees' table.");
        }
    }
}



package assisted_project;
//Java Programs to illustrate 
//use of Interface to solve 
//Diamond Problem  
//Interfaces Declared 
interface Parent1 { 
	void fun(); 
} 
//Interfaces Declared 
interface Parent2 { 
	void fun(); 
} 
//Inheritance using Interfaces 
class test implements Parent1, Parent2 { 
	public void fun() 
	{ 
		System.out.println("fun function"); 
	} 
} 
class Diamond_problem { 
	// main function 
	public static void main(String[] args) 
	{ 
		test t = new test(); 
		t.fun(); 
	} 
}


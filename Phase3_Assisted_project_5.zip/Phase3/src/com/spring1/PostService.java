package com.spring1;
package com.example.demo.service;
import com.example.demo.model.Post;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PostService {
 private final String apiUrl = "https://jsonplaceholder.typicode.com/posts";

 private final RestTemplate restTemplate;

 public PostService(RestTemplate restTemplate) {
     this.restTemplate = restTemplate;
 }

 public Post getPostById(Long id) {
     String url = apiUrl + "/" + id;
     return restTemplate.getForObject(url, Post.class);
 }
}

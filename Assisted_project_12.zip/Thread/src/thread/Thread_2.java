package thread;
//using Runnable interface 
class hi implements Runnable{
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("hi");
			try {Thread.sleep(1000);} catch(Exception e) {	}
		}
	}
}
class hello implements Runnable{
	public void run() {
		for(int i=1;i<=5;i++) {
			System.out.println("hello");
			try {Thread.sleep(1000);} catch(Exception e) {	}
		}
	}
}
public class Thread_2 {
	public static void main(String[] args) throws Exception{
			hi obj1=new hi();// Runnable obj1=new hi() this is the another way to write this line 
			//because we implements Runnable interface
			hello obj2=new hello();
			Thread t1=new Thread(obj1);
			Thread t2= new Thread(obj2);
			//thread priority
			System.out.println(t1.getName());// to know the Thread name
			t2.setName("HI");//to change the thread name
			//another way to change thread name Thread t1=new Thread(obj1,"hi");
			System.out.println(t2.getName());
			t2.setPriority(1);
			System.out.println(t1.getPriority());// to know priority 
			System.out.println(t2.getPriority());
			t1.start();
			try {Thread.sleep(10);} catch(Exception e) {	}
			t2.start();
			System.out.println(t1.isAlive());// it's check that thread is completed it's work 
			//after printing hi ,hello we want to print bye
			//we write print line but we want print in at end that's why we 
		    t1.join();//join will help main thread to wait to end t1's work
		    t2.join();
			System.out.println("bye");

	}
}

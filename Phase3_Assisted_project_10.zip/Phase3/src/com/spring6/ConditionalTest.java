package com.spring6;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIfSystemProperty;

public class ConditionalTest {

    @Test
    @DisabledIfSystemProperty(named = "run.disabled.tests", matches = "true", disabledReason = "Tests are disabled")
    public void testEnabled() {
        System.out.println("This test is enabled and will run.");
        // Add your test logic here
    }

    @Test
    @DisabledIfSystemProperty(named = "run.disabled.tests", matches = "true", disabledReason = "Tests are disabled")
    public void testDisabled() {
        System.out.println("This test is disabled and won't run.");
        // Add your test logic here (this won't be executed)
    }
}


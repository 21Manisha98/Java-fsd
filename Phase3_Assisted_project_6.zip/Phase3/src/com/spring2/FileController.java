package com.spring2;
//src/main/java/com/example/demo/controller/FileController.java
package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;

@Controller
public class FileController {

 @GetMapping("/")
 public String home() {
     return "index";
 }

 @PostMapping("/upload")
 public String handleFileUpload(@RequestParam("file") MultipartFile file, Model model) {
     try {
         String fileName = file.getOriginalFilename();
         byte[] fileContent = file.getBytes();
         String base64Content = Base64.getEncoder().encodeToString(fileContent);

         // In a real-world scenario, you would save the file to a more permanent location
         // and store the file information in a database.

         model.addAttribute("fileName", fileName);
         model.addAttribute("fileContent", base64Content);

         return "success";
     } catch (IOException e) {
         model.addAttribute("message", "Error uploading file");
         return "error";
     }
 }
}



package phase2;
package com.example.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Entity{

 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private int id;

 private String productName;
 private double price;
 private int quantity;

 // Getters and setters
 public int getId() {
     return id;
 }

 public void setId(int id) {
     this.id = id;
 }

 // Getter and Setter for productName
 public String getProductName() {
     return productName;
 }

 public void setProductName(String productName) {
     this.productName = productName;
 }

 // Getter and Setter for price
 public double getPrice() {
     return price;
 }

 public void setPrice(double price) {
     this.price = price;
 }

 // Getter and Setter for quantity
 public int getQuantity() {
     return quantity;
 }

 public void setQuantity(int quantity) {
     this.quantity = quantity;
 }
}

